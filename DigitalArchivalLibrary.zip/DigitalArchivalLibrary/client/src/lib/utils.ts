import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateString: string | Date): string {
  if (!dateString) return '';
  
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      return dateString.toString();
    }
    
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  } catch (e) {
    return dateString.toString();
  }
}

export function getCategoryColorClasses(categoryName: string): {
  bg: string;
  text: string;
} {
  switch (categoryName.toLowerCase()) {
    case 'manuscript':
    case 'manuscripts':
      return { bg: 'bg-indigo-100', text: 'text-indigo-800' };
    case 'map':
    case 'maps':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'letter':
    case 'letters':
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
    case 'record':
    case 'records':
    case 'historical record':
    case 'historical records':
      return { bg: 'bg-yellow-100', text: 'text-yellow-800' };
    default:
      return { bg: 'bg-gray-100', text: 'text-gray-800' };
  }
}

export function truncateText(text: string, maxLength: number = 100): string {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  
  return text.slice(0, maxLength) + '...';
}
