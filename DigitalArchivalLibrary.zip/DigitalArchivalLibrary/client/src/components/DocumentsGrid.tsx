import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Grid3x3, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import DocumentCard from "./DocumentCard";
import DocumentListItem from "./DocumentList";
import Pagination from "./Pagination";
import { Skeleton } from "@/components/ui/skeleton";
import type { Document, Category } from "@shared/schema";

interface DocumentsGridProps {
  categoryId: number | null;
  searchQuery: string;
  timePeriods: string[];
  onViewDocument: (document: Document) => void;
}

export default function DocumentsGrid({ 
  categoryId, 
  searchQuery, 
  timePeriods,
  onViewDocument 
}: DocumentsGridProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  // Fetch documents
  const { data: documents, isLoading } = useQuery<Document[]>({
    queryKey: ['/api/documents', categoryId, searchQuery],
    queryFn: async () => {
      let url = '/api/documents';
      const params = new URLSearchParams();
      
      if (categoryId) {
        params.append('categoryId', categoryId.toString());
      }
      
      if (searchQuery) {
        params.append('search', searchQuery);
      }
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Failed to fetch documents');
      }
      
      return response.json();
    }
  });

  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Filter documents by time period if selected
  const filteredDocuments = documents?.filter(doc => {
    if (timePeriods.length === 0) return true;
    
    // Check if document date contains any of the selected time periods
    return timePeriods.some(period => 
      doc.date?.toLowerCase().includes(period.toLowerCase())
    );
  }) || [];

  // Calculate pagination
  const totalItems = filteredDocuments.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  
  // Get current page items
  const currentItems = filteredDocuments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [categoryId, searchQuery, timePeriods]);

  // Get category name by id
  const getCategoryName = (categoryId: number): string => {
    return categories?.find(c => c.id === categoryId)?.name || 'Unknown';
  };

  // Loading skeletons
  const renderSkeletons = () => {
    return Array(4).fill(0).map((_, index) => (
      <div key={`skeleton-${index}`} className="bg-white rounded-lg shadow overflow-hidden">
        <Skeleton className="h-48 w-full" />
        <div className="p-4">
          <Skeleton className="h-6 w-20 mb-2" />
          <Skeleton className="h-6 w-full mb-1" />
          <Skeleton className="h-4 w-3/4 mb-3" />
          <div className="flex justify-between items-center">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-5 w-5 rounded-full" />
          </div>
        </div>
      </div>
    ));
  };

  return (
    <div className="w-full md:w-3/4 lg:w-4/5">
      {/* View toggle buttons */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="mb-4 md:mb-0">
          <h2 className="text-xl font-semibold text-gray-800">
            {categoryId 
              ? `${getCategoryName(categoryId)} Documents` 
              : 'All Documents'}
            {searchQuery && ` matching "${searchQuery}"`}
          </h2>
        </div>
        <div className="flex space-x-2">
          <Button
            variant={viewMode === 'grid' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setViewMode('grid')}
          >
            <Grid3x3 className="h-5 w-5 mr-2" />
            Grid
          </Button>
          <Button
            variant={viewMode === 'list' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            <List className="h-5 w-5 mr-2" />
            List
          </Button>
        </div>
      </div>

      {/* Grid view */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {isLoading ? (
            renderSkeletons()
          ) : currentItems.length > 0 ? (
            currentItems.map((document) => (
              <DocumentCard
                key={document.id}
                document={document}
                categoryName={getCategoryName(document.categoryId)}
                onViewDetail={() => onViewDocument(document)}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-10">
              <h3 className="text-lg font-medium text-gray-700">No documents found</h3>
              <p className="text-gray-500 mt-2">Try adjusting your search or filters</p>
            </div>
          )}
        </div>
      )}

      {/* List view */}
      {viewMode === 'list' && (
        <div className="space-y-4">
          {isLoading ? (
            Array(3).fill(0).map((_, index) => (
              <div key={`list-skeleton-${index}`} className="bg-white rounded-lg shadow p-4 flex">
                <Skeleton className="w-32 h-32 flex-shrink-0 mr-4" />
                <div className="flex-grow">
                  <div className="flex justify-between items-start">
                    <div>
                      <Skeleton className="h-6 w-20 mb-2" />
                      <Skeleton className="h-6 w-full mb-1" />
                    </div>
                    <Skeleton className="h-5 w-5 rounded-full" />
                  </div>
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-3" />
                  <Skeleton className="h-4 w-24" />
                </div>
              </div>
            ))
          ) : currentItems.length > 0 ? (
            currentItems.map((document) => (
              <DocumentListItem
                key={document.id}
                document={document}
                categoryName={getCategoryName(document.categoryId)}
                onViewDetail={() => onViewDocument(document)}
              />
            ))
          ) : (
            <div className="text-center py-10">
              <h3 className="text-lg font-medium text-gray-700">No documents found</h3>
              <p className="text-gray-500 mt-2">Try adjusting your search or filters</p>
            </div>
          )}
        </div>
      )}

      {/* Pagination */}
      {totalItems > 0 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          totalItems={totalItems}
          itemsPerPage={itemsPerPage}
          onPageChange={setCurrentPage}
        />
      )}
    </div>
  );
}
