import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { insertDocumentSchema } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { X, Upload } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Category, Document } from "@shared/schema";

// Extend the document schema with form validation
const formSchema = insertDocumentSchema.extend({
  image: z.instanceof(FileList).refine(files => files.length > 0, {
    message: "Image is required",
  }),
});

type FormValues = z.infer<typeof formSchema>;

interface AddDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  editDocument?: Document | null;
}

export default function AddDocumentModal({
  isOpen,
  onClose,
  editDocument = null
}: AddDocumentModalProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    enabled: isOpen,
  });

  // Create form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: editDocument?.title || "",
      categoryId: editDocument?.categoryId || 0,
      date: editDocument?.date || "",
      source: editDocument?.source || "",
      reference: editDocument?.reference || "",
      author: editDocument?.author || "",
      transcription: editDocument?.transcription || "",
      image: undefined
    },
  });

  // Set form values when editing a document
  useState(() => {
    if (editDocument) {
      form.reset({
        title: editDocument.title,
        categoryId: editDocument.categoryId,
        date: editDocument.date || "",
        source: editDocument.source || "",
        reference: editDocument.reference || "",
        author: editDocument.author || "",
        transcription: editDocument.transcription || "",
        image: undefined
      });
      
      // Set preview image
      setPreviewUrl(editDocument.imagePath);
    } else {
      form.reset({
        title: "",
        categoryId: 0,
        date: "",
        source: "",
        reference: "",
        author: "",
        transcription: "",
        image: undefined
      });
      setPreviewUrl(null);
    }
  });

  // Handle image preview
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setPreviewUrl(null);
    }
  };

  // Create document mutation
  const createMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const formData = new FormData();
      formData.append('title', data.title);
      formData.append('categoryId', data.categoryId.toString());
      if (data.date) formData.append('date', data.date);
      if (data.source) formData.append('source', data.source);
      if (data.reference) formData.append('reference', data.reference);
      if (data.author) formData.append('author', data.author);
      if (data.transcription) formData.append('transcription', data.transcription);
      
      // Append the first image file
      if (data.image instanceof FileList && data.image.length > 0) {
        formData.append('image', data.image[0]);
      }
      
      const response = await fetch('/api/documents', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create document');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      toast({
        title: 'Success',
        description: 'Document created successfully',
      });
      onClose();
      form.reset();
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create document',
        variant: 'destructive',
      });
    }
  });

  // Update document mutation
  const updateMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      if (!editDocument) throw new Error('No document to update');
      
      const formData = new FormData();
      formData.append('title', data.title);
      formData.append('categoryId', data.categoryId.toString());
      if (data.date) formData.append('date', data.date);
      if (data.source) formData.append('source', data.source);
      if (data.reference) formData.append('reference', data.reference);
      if (data.author) formData.append('author', data.author);
      if (data.transcription) formData.append('transcription', data.transcription);
      
      // Append the image file if a new one was selected
      if (data.image instanceof FileList && data.image.length > 0) {
        formData.append('image', data.image[0]);
      }
      
      const response = await fetch(`/api/documents/${editDocument.id}`, {
        method: 'PATCH',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update document');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      toast({
        title: 'Success',
        description: 'Document updated successfully',
      });
      onClose();
      form.reset();
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update document',
        variant: 'destructive',
      });
    }
  });

  const onSubmit = (data: FormValues) => {
    if (editDocument) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-white max-w-3xl w-full max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="px-6 py-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
          <DialogTitle className="text-xl font-semibold text-gray-800">
            {editDocument ? 'Edit Document' : 'Add New Document'}
          </DialogTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-6 w-6 text-gray-400 hover:text-gray-500" />
          </Button>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="flex-grow overflow-auto p-6 space-y-6">
              {/* Document title and category */}
              <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-4">
                      <FormLabel>Document Title</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="categoryId"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Category</FormLabel>
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories?.map((category) => (
                            <SelectItem key={category.id} value={category.id.toString()}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Date and source */}
              <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-3">
                      <FormLabel>Date</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., 1687, 16th century" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="source"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-3">
                      <FormLabel>Source</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., Cambridge University" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Reference number and author */}
              <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <FormField
                  control={form.control}
                  name="reference"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-3">
                      <FormLabel>Reference Number</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="author"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-3">
                      <FormLabel>Author</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Document image */}
              <FormField
                control={form.control}
                name="image"
                render={({ field: { value, onChange, ...fieldProps } }) => (
                  <FormItem>
                    <FormLabel>Document Image</FormLabel>
                    <FormControl>
                      <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                        {previewUrl ? (
                          <div className="space-y-4 text-center">
                            <img 
                              src={previewUrl} 
                              alt="Preview" 
                              className="mx-auto h-40 object-cover rounded"
                            />
                            <div className="flex justify-center">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setPreviewUrl(null);
                                  onChange(undefined);
                                }}
                              >
                                Replace Image
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-1 text-center">
                            <Upload className="mx-auto h-12 w-12 text-gray-400" />
                            <div className="flex text-sm text-gray-600">
                              <label htmlFor="document-image" className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-indigo-700 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                                <span>Upload a file</span>
                                <input
                                  id="document-image"
                                  type="file"
                                  className="sr-only"
                                  accept="image/*"
                                  onChange={(e) => {
                                    onChange(e.target.files);
                                    handleImageChange(e);
                                  }}
                                  {...fieldProps}
                                />
                              </label>
                              <p className="pl-1">or drag and drop</p>
                            </div>
                            <p className="text-xs text-gray-500">PNG, JPG, TIFF up to 10MB</p>
                          </div>
                        )}
                      </div>
                    </FormControl>
                    <FormMessage />
                    {editDocument && !value && (
                      <FormDescription>
                        {previewUrl ? "Using existing image. Upload a new one to replace it." : ""}
                      </FormDescription>
                    )}
                  </FormItem>
                )}
              />
              
              {/* Document transcription */}
              <FormField
                control={form.control}
                name="transcription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Transcription</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        rows={6}
                      />
                    </FormControl>
                    <FormDescription>
                      Add the transcription or description of the document if available.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Modal footer */}
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="mr-3"
                disabled={isPending}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isPending}
              >
                {isPending ? 'Saving...' : (editDocument ? 'Update Document' : 'Save Document')}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
