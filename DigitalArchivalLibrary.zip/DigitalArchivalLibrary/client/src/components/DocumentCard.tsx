import { MoreVertical } from "lucide-react";
import { cn, getCategoryColorClasses } from "@/lib/utils";
import type { Document } from "@shared/schema";

interface DocumentCardProps {
  document: Document;
  categoryName: string;
  onViewDetail: () => void;
}

export default function DocumentCard({ document, categoryName, onViewDetail }: DocumentCardProps) {
  const categoryColors = getCategoryColorClasses(categoryName);
  
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="image-zoom-container h-48 overflow-hidden bg-gray-200">
        <img 
          src={document.imagePath} 
          alt={document.title} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
        />
      </div>
      <div className="p-4">
        <span className={cn(
          "inline-block px-2 py-1 text-xs font-semibold rounded-full mb-2",
          categoryColors.bg,
          categoryColors.text
        )}>
          {categoryName}
        </span>
        <h3 className="document-title text-lg font-medium text-gray-900 mb-1" style={{ fontFamily: "'Libre Baskerville', serif" }}>
          {document.title}
        </h3>
        <p className="text-sm text-gray-500 mb-3">
          {document.date && `${document.date} | `}{document.source}
        </p>
        <div className="flex justify-between items-center">
          <button 
            className="text-sm text-primary hover:text-indigo-700 font-medium"
            onClick={onViewDetail}
          >
            View Details
          </button>
          <MoreVertical className="h-5 w-5 text-gray-400 hover:text-gray-600 cursor-pointer" />
        </div>
      </div>
    </div>
  );
}
