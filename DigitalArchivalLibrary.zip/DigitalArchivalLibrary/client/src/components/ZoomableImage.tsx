import { useState, useRef, useEffect } from "react";
import { ZoomIn, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface ZoomableImageProps {
  src: string;
  alt: string;
  zoomOpen: boolean;
  onZoomToggle: () => void;
}

export default function ZoomableImage({ src, alt, zoomOpen, onZoomToggle }: ZoomableImageProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [startPosition, setStartPosition] = useState({ x: 0, y: 0 });
  const imgRef = useRef<HTMLImageElement>(null);

  // Reset position when zoom mode changes
  useEffect(() => {
    if (!zoomOpen) {
      setPosition({ x: 0, y: 0 });
    }
  }, [zoomOpen]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!zoomOpen) return;
    setIsDragging(true);
    setStartPosition({
      x: e.clientX - position.x,
      y: e.clientY - position.y
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPosition({
      x: e.clientX - startPosition.x,
      y: e.clientY - startPosition.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    const handleMouseUpOutside = () => {
      setIsDragging(false);
    };

    document.addEventListener('mouseup', handleMouseUpOutside);
    return () => {
      document.removeEventListener('mouseup', handleMouseUpOutside);
    };
  }, []);

  return (
    <>
      {/* Regular image view */}
      <img 
        ref={imgRef}
        src={src} 
        alt={alt} 
        className="w-full rounded cursor-zoom-in"
        onClick={onZoomToggle}
      />
      
      {/* Zoom overlay */}
      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-20 opacity-0 hover:opacity-100 transition-opacity">
        <button 
          onClick={onZoomToggle}
          className="mx-2 bg-white rounded-full p-2 shadow hover:bg-gray-100"
        >
          <ZoomIn className="h-6 w-6" />
        </button>
      </div>

      {/* Zoomed view (modal) */}
      <div className={cn(
        "fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center",
        zoomOpen ? "block" : "hidden"
      )}>
        <div className="relative w-full h-full">
          <button 
            onClick={onZoomToggle}
            className="absolute top-4 right-4 text-white hover:text-gray-300 focus:outline-none z-10"
          >
            <XCircle className="h-8 w-8" />
          </button>
          <div className="w-full h-full overflow-auto p-4">
            <img 
              src={src} 
              alt={`${alt} - zoomed`} 
              className={cn(
                "max-w-none cursor-move",
                isDragging ? "cursor-grabbing" : "cursor-grab"
              )}
              style={{ 
                transform: `translate(${position.x}px, ${position.y}px)`,
                maxWidth: '150%',
                maxHeight: '150%'
              }}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
            />
          </div>
        </div>
      </div>
    </>
  );
}
