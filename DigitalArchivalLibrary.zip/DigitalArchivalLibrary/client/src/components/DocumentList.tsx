import { MoreVertical } from "lucide-react";
import { cn, getCategoryColorClasses, truncateText } from "@/lib/utils";
import type { Document } from "@shared/schema";

interface DocumentListItemProps {
  document: Document;
  categoryName: string;
  onViewDetail: () => void;
}

export default function DocumentListItem({ document, categoryName, onViewDetail }: DocumentListItemProps) {
  const categoryColors = getCategoryColorClasses(categoryName);
  
  return (
    <div className="bg-white rounded-lg shadow p-4 flex">
      <div className="w-32 h-32 flex-shrink-0 overflow-hidden rounded mr-4">
        <img 
          src={document.imagePath} 
          alt={document.title} 
          className="w-full h-full object-cover"
        />
      </div>
      <div className="flex-grow">
        <div className="flex justify-between items-start">
          <div>
            <span className={cn(
              "inline-block px-2 py-1 text-xs font-semibold rounded-full mb-2",
              categoryColors.bg,
              categoryColors.text
            )}>
              {categoryName}
            </span>
            <h3 className="document-title text-lg font-medium text-gray-900" style={{ fontFamily: "'Libre Baskerville', serif" }}>
              {document.title}
            </h3>
          </div>
          <MoreVertical className="h-5 w-5 text-gray-400 hover:text-gray-600 cursor-pointer" />
        </div>
        <p className="text-sm text-gray-500 mb-2">
          {document.date && `${document.date} | `}{document.source}
        </p>
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {truncateText(document.transcription || '', 150)}
        </p>
        <button 
          className="text-sm text-primary hover:text-indigo-700 font-medium"
          onClick={onViewDetail}
        >
          View Details
        </button>
      </div>
    </div>
  );
}
