import { useQuery } from "@tanstack/react-query";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import type { Category } from "@shared/schema";

interface CategorySidebarProps {
  selectedCategory: number | null;
  onCategorySelect: (categoryId: number | null) => void;
  selectedTimePeriods: string[];
  onTimePeriodChange: (period: string) => void;
}

export default function CategorySidebar({ 
  selectedCategory,
  onCategorySelect,
  selectedTimePeriods,
  onTimePeriodChange
}: CategorySidebarProps) {
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const timePeriods = [
    { id: "1800s", label: "1800s" },
    { id: "1900s", label: "1900s" },
    { id: "2000s", label: "2000s" },
  ];

  return (
    <div className="w-full md:w-1/4 lg:w-1/5 md:pr-6 mb-6 md:mb-0">
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-lg font-semibold mb-3 text-gray-800">Categories</h2>
        <ul className="space-y-1">
          <li>
            <a 
              href="#" 
              onClick={(e) => {
                e.preventDefault();
                onCategorySelect(null);
              }}
              className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                selectedCategory === null 
                  ? 'bg-primary text-white' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              All Documents
              <span className={`ml-auto ${
                selectedCategory === null 
                  ? 'bg-indigo-200 text-indigo-800' 
                  : 'bg-gray-100 text-gray-600'
              } py-0.5 px-2 rounded-full text-xs`}>
                {isLoading ? '...' : categories?.reduce((acc, cat) => acc + cat.count, 0) || 0}
              </span>
            </a>
          </li>
          
          {categories?.map((category) => (
            <li key={category.id}>
              <a 
                href="#" 
                onClick={(e) => {
                  e.preventDefault();
                  onCategorySelect(category.id);
                }}
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                  selectedCategory === category.id 
                    ? 'bg-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                {category.name}
                <span className={`ml-auto ${
                  selectedCategory === category.id 
                    ? 'bg-indigo-200 text-indigo-800' 
                    : 'bg-gray-100 text-gray-600'
                } py-0.5 px-2 rounded-full text-xs`}>
                  {category.count}
                </span>
              </a>
            </li>
          ))}
        </ul>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="text-sm font-medium text-gray-900">Time Period</h3>
          <div className="mt-2">
            {timePeriods.map((period) => (
              <div className="flex items-center mt-2" key={period.id}>
                <Checkbox 
                  id={`period-${period.id}`} 
                  checked={selectedTimePeriods.includes(period.id)}
                  onCheckedChange={() => onTimePeriodChange(period.id)}
                />
                <Label 
                  htmlFor={`period-${period.id}`} 
                  className="ml-3 text-sm text-gray-700"
                >
                  {period.label}
                </Label>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
