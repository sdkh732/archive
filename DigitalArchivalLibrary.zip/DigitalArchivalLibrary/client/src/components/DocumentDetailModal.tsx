import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Edit, X } from "lucide-react";
import { getCategoryColorClasses } from "@/lib/utils";
import ZoomableImage from "./ZoomableImage";
import type { Document, Category } from "@shared/schema";

interface DocumentDetailModalProps {
  document: Document | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (document: Document) => void;
}

export default function DocumentDetailModal({
  document,
  isOpen,
  onClose,
  onEdit
}: DocumentDetailModalProps) {
  const [zoomOpen, setZoomOpen] = useState(false);
  
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    enabled: isOpen && document !== null,
  });
  
  if (!document) {
    return null;
  }
  
  const categoryName = categories?.find(c => c.id === document.categoryId)?.name || 'Unknown';
  
  const handleDownload = () => {
    // Create a link to download the image
    const link = document.imagePath;
    const a = document.createElement('a');
    a.href = link;
    a.download = `${document.title.replace(/\s+/g, '_')}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-white max-w-6xl w-full max-h-[90vh] flex flex-col p-0">
        {/* Modal header */}
        <DialogHeader className="px-6 py-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
          <DialogTitle className="text-xl font-semibold text-gray-800 document-title" style={{ fontFamily: "'Libre Baskerville', serif" }}>
            {document.title}
          </DialogTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-6 w-6 text-gray-400 hover:text-gray-500" />
          </Button>
        </DialogHeader>
        
        {/* Modal content */}
        <div className="flex-grow overflow-auto p-6">
          <div className="flex flex-col lg:flex-row">
            {/* Document image */}
            <div className="lg:w-3/5 mb-6 lg:mb-0 lg:pr-6">
              <div className="bg-gray-100 rounded-lg overflow-hidden shadow-inner p-2">
                <div className="relative">
                  <ZoomableImage
                    src={document.imagePath}
                    alt={document.title}
                    zoomOpen={zoomOpen}
                    onZoomToggle={() => setZoomOpen(!zoomOpen)}
                  />
                </div>
              </div>
            </div>
            
            {/* Document metadata and text */}
            <div className="lg:w-2/5">
              <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Document Information</h3>
                <dl className="grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-2">
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Category</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      <span className={`inline-block px-2 py-1 text-xs font-semibold rounded-full ${
                        getCategoryColorClasses(categoryName).bg
                      } ${
                        getCategoryColorClasses(categoryName).text
                      }`}>
                        {categoryName}
                      </span>
                    </dd>
                  </div>
                  {document.date && (
                    <div className="sm:col-span-1">
                      <dt className="text-sm font-medium text-gray-500">Date</dt>
                      <dd className="mt-1 text-sm text-gray-900">{document.date}</dd>
                    </div>
                  )}
                  {document.author && (
                    <div className="sm:col-span-1">
                      <dt className="text-sm font-medium text-gray-500">Author</dt>
                      <dd className="mt-1 text-sm text-gray-900">{document.author}</dd>
                    </div>
                  )}
                  {document.source && (
                    <div className="sm:col-span-1">
                      <dt className="text-sm font-medium text-gray-500">Source</dt>
                      <dd className="mt-1 text-sm text-gray-900">{document.source}</dd>
                    </div>
                  )}
                  {document.reference && (
                    <div className="sm:col-span-2">
                      <dt className="text-sm font-medium text-gray-500">Reference Number</dt>
                      <dd className="mt-1 text-sm text-gray-900">{document.reference}</dd>
                    </div>
                  )}
                </dl>
              </div>
              
              {document.transcription && (
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-3">Transcription</h3>
                  <div className="prose prose-sm max-w-none text-gray-700 bg-white rounded-lg border border-gray-200 p-4 max-h-96 overflow-y-auto">
                    {document.transcription.split('\n').map((paragraph, index) => (
                      <p key={index}>{paragraph}</p>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Modal footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between">
          <div>
            <Button 
              variant="outline"
              onClick={handleDownload}
              className="inline-flex items-center"
            >
              <Download className="h-5 w-5 mr-2" />
              Download
            </Button>
          </div>
          <div>
            <Button
              onClick={() => onEdit(document)}
              className="inline-flex items-center"
            >
              <Edit className="h-5 w-5 mr-2" />
              Edit Document
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
