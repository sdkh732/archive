import { useState } from "react";
import Header from "@/components/Header";
import SearchBar from "@/components/SearchBar";
import CategorySidebar from "@/components/CategorySidebar";
import DocumentsGrid from "@/components/DocumentsGrid";
import DocumentDetailModal from "@/components/DocumentDetailModal";
import AddDocumentModal from "@/components/AddDocumentModal";
import Footer from "@/components/Footer";
import type { Document } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState<Document | null>(null);
  const [selectedTimePeriods, setSelectedTimePeriods] = useState<string[]>([]);

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
  };

  const handleCategorySelect = (categoryId: number | null) => {
    setSelectedCategory(categoryId);
  };

  const handleTimePeriodChange = (period: string) => {
    setSelectedTimePeriods(prev => 
      prev.includes(period)
        ? prev.filter(p => p !== period)
        : [...prev, period]
    );
  };

  const handleViewDocument = (document: Document) => {
    setSelectedDocument(document);
    setDetailModalOpen(true);
  };

  const handleCloseDetailModal = () => {
    setDetailModalOpen(false);
    setSelectedDocument(null);
  };

  const handleAddDocument = () => {
    setEditingDocument(null);
    setAddModalOpen(true);
  };

  const handleEditDocument = (document: Document) => {
    setEditingDocument(document);
    setDetailModalOpen(false);
    setAddModalOpen(true);
  };

  const handleCloseAddModal = () => {
    setAddModalOpen(false);
    setEditingDocument(null);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header onAddDocument={handleAddDocument} />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Search and filter section */}
          <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
            <SearchBar 
              searchQuery={searchQuery} 
              onSearchChange={handleSearchChange} 
            />
          </div>

          {/* Main content container with sidebar and documents */}
          <div className="flex flex-col md:flex-row">
            <CategorySidebar 
              selectedCategory={selectedCategory} 
              onCategorySelect={handleCategorySelect}
              selectedTimePeriods={selectedTimePeriods}
              onTimePeriodChange={handleTimePeriodChange}
            />
            
            <DocumentsGrid 
              categoryId={selectedCategory}
              searchQuery={searchQuery}
              timePeriods={selectedTimePeriods}
              onViewDocument={handleViewDocument}
            />
          </div>
        </div>
      </main>

      <Footer />

      {/* Modals */}
      <DocumentDetailModal 
        document={selectedDocument}
        isOpen={detailModalOpen}
        onClose={handleCloseDetailModal}
        onEdit={handleEditDocument}
      />

      <AddDocumentModal 
        isOpen={addModalOpen}
        onClose={handleCloseAddModal}
        editDocument={editingDocument}
      />
    </div>
  );
}
