import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import fs from "fs";
import path from "path";
import { insertDocumentSchema, insertCategorySchema } from "@shared/schema";
import { z } from "zod";

// Setup multer for memory storage
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

// Create uploads directory if it doesn't exist
const uploadsDir = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve uploaded files
  app.use('/uploads', express.static(uploadsDir));

  // API Routes
  // Get all categories
  app.get('/api/categories', async (req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (err) {
      console.error('Error fetching categories:', err);
      res.status(500).json({ message: 'Failed to fetch categories' });
    }
  });

  // Create a new category
  app.post('/api/categories', async (req: Request, res: Response) => {
    try {
      const validatedData = insertCategorySchema.parse(req.body);
      
      // Check if category already exists
      const existingCategory = await storage.getCategoryByName(validatedData.name);
      if (existingCategory) {
        return res.status(400).json({ message: 'Category already exists' });
      }
      
      const category = await storage.createCategory(validatedData);
      res.status(201).json(category);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid category data', errors: err.errors });
      }
      console.error('Error creating category:', err);
      res.status(500).json({ message: 'Failed to create category' });
    }
  });

  // Get all documents or filtered by category/search
  app.get('/api/documents', async (req: Request, res: Response) => {
    try {
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      const search = req.query.search as string | undefined;
      
      const documents = await storage.getDocuments(categoryId, search);
      res.json(documents);
    } catch (err) {
      console.error('Error fetching documents:', err);
      res.status(500).json({ message: 'Failed to fetch documents' });
    }
  });

  // Get a document by ID
  app.get('/api/documents/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getDocumentById(id);
      
      if (!document) {
        return res.status(404).json({ message: 'Document not found' });
      }
      
      res.json(document);
    } catch (err) {
      console.error('Error fetching document:', err);
      res.status(500).json({ message: 'Failed to fetch document' });
    }
  });

  // Create a new document
  app.post('/api/documents', upload.single('image'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Image file is required' });
      }
      
      // Parse the rest of the form data
      const documentData = {
        title: req.body.title,
        categoryId: parseInt(req.body.categoryId),
        date: req.body.date || null,
        source: req.body.source || null,
        reference: req.body.reference || null,
        author: req.body.author || null,
        transcription: req.body.transcription || null,
      };
      
      // Validate the document data
      const validatedData = insertDocumentSchema.parse(documentData);
      
      // Get file extension
      const originalFilename = req.file.originalname;
      const fileExtension = path.extname(originalFilename);
      
      // Create the document
      const document = await storage.createDocument(
        validatedData, 
        req.file.buffer,
        fileExtension
      );
      
      res.status(201).json(document);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid document data', errors: err.errors });
      }
      console.error('Error creating document:', err);
      res.status(500).json({ message: 'Failed to create document' });
    }
  });

  // Update a document
  app.patch('/api/documents/:id', upload.single('image'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      // Check if document exists
      const existingDocument = await storage.getDocumentById(id);
      if (!existingDocument) {
        return res.status(404).json({ message: 'Document not found' });
      }
      
      // Parse the form data
      const documentData: any = {};
      if (req.body.title) documentData.title = req.body.title;
      if (req.body.categoryId) documentData.categoryId = parseInt(req.body.categoryId);
      if ('date' in req.body) documentData.date = req.body.date || null;
      if ('source' in req.body) documentData.source = req.body.source || null;
      if ('reference' in req.body) documentData.reference = req.body.reference || null;
      if ('author' in req.body) documentData.author = req.body.author || null;
      if ('transcription' in req.body) documentData.transcription = req.body.transcription || null;
      
      // If we have a new image
      if (req.file) {
        // Delete old image
        if (existingDocument.imagePath) {
          const oldImagePath = path.join(process.cwd(), existingDocument.imagePath.replace(/^\/uploads/, 'uploads'));
          if (fs.existsSync(oldImagePath)) {
            fs.unlinkSync(oldImagePath);
          }
        }
        
        // Generate a unique filename
        const originalFilename = req.file.originalname;
        const fileExtension = path.extname(originalFilename);
        const filename = `doc_${id}_${Date.now()}${fileExtension}`;
        const imagePath = path.join(uploadsDir, filename);
        
        // Save the image to disk
        fs.writeFileSync(imagePath, req.file.buffer);
        
        // Update image path
        documentData.imagePath = `/uploads/${filename}`;
      }
      
      // Update the document
      const updatedDocument = await storage.updateDocument(id, documentData);
      
      res.json(updatedDocument);
    } catch (err) {
      console.error('Error updating document:', err);
      res.status(500).json({ message: 'Failed to update document' });
    }
  });

  // Delete a document
  app.delete('/api/documents/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteDocument(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Document not found' });
      }
      
      res.status(204).send();
    } catch (err) {
      console.error('Error deleting document:', err);
      res.status(500).json({ message: 'Failed to delete document' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Import express here to avoid TS errors
import express from "express";
