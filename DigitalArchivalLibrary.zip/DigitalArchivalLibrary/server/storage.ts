import { 
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  documents, type Document, type InsertDocument
} from "@shared/schema";
import fs from "fs";
import path from "path";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category methods
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  getCategoryByName(name: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategoryCount(id: number, increment: number): Promise<Category | undefined>;
  
  // Document methods
  getDocuments(categoryId?: number, search?: string): Promise<Document[]>;
  getDocumentById(id: number): Promise<Document | undefined>;
  createDocument(document: InsertDocument, imageBuffer: Buffer, extension: string): Promise<Document>;
  updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private documents: Map<number, Document>;
  private userIdCounter: number;
  private categoryIdCounter: number;
  private documentIdCounter: number;
  private uploadsDir: string;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.documents = new Map();
    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.documentIdCounter = 1;
    
    // Create uploads directory if it doesn't exist
    this.uploadsDir = path.resolve(process.cwd(), 'uploads');
    if (!fs.existsSync(this.uploadsDir)) {
      fs.mkdirSync(this.uploadsDir, { recursive: true });
    }
    
    // Initialize with default categories
    this.initializeCategories();
  }

  private initializeCategories() {
    const defaultCategories = [
      { name: "Manuscripts" },
      { name: "Maps" },
      { name: "Letters" },
      { name: "Historical Records" }
    ];
    
    defaultCategories.forEach(category => {
      this.createCategory(category);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryByName(name: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.name.toLowerCase() === name.toLowerCase(),
    );
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { ...insertCategory, id, count: 0 };
    this.categories.set(id, category);
    return category;
  }

  async updateCategoryCount(id: number, increment: number): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const updatedCategory = { 
      ...category, 
      count: Math.max(0, category.count + increment)
    };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }

  // Document methods
  async getDocuments(categoryId?: number, search?: string): Promise<Document[]> {
    let filteredDocs = Array.from(this.documents.values());
    
    if (categoryId) {
      filteredDocs = filteredDocs.filter(doc => doc.categoryId === categoryId);
    }
    
    if (search) {
      const searchLower = search.toLowerCase();
      filteredDocs = filteredDocs.filter(doc => {
        return (
          doc.title.toLowerCase().includes(searchLower) ||
          (doc.author && doc.author.toLowerCase().includes(searchLower)) ||
          (doc.source && doc.source.toLowerCase().includes(searchLower)) ||
          (doc.transcription && doc.transcription.toLowerCase().includes(searchLower))
        );
      });
    }
    
    // Sort by newest first
    return filteredDocs.sort((a, b) => {
      const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return dateB - dateA;
    });
  }

  async getDocumentById(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async createDocument(document: InsertDocument, imageBuffer: Buffer, extension: string): Promise<Document> {
    const id = this.documentIdCounter++;
    
    // Generate a unique filename
    const filename = `doc_${id}_${Date.now()}${extension}`;
    const imagePath = path.join(this.uploadsDir, filename);
    
    // Save the image to disk
    fs.writeFileSync(imagePath, imageBuffer);
    
    // Create document record
    const newDocument: Document = {
      ...document,
      id,
      imagePath: `/uploads/${filename}`,
      createdAt: new Date()
    };
    
    this.documents.set(id, newDocument);
    
    // Update category count
    await this.updateCategoryCount(document.categoryId, 1);
    
    return newDocument;
  }

  async updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document | undefined> {
    const existingDocument = this.documents.get(id);
    if (!existingDocument) return undefined;
    
    // Check if category changed
    if (document.categoryId && document.categoryId !== existingDocument.categoryId) {
      // Decrement old category count
      await this.updateCategoryCount(existingDocument.categoryId, -1);
      // Increment new category count
      await this.updateCategoryCount(document.categoryId, 1);
    }
    
    const updatedDocument = { ...existingDocument, ...document };
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<boolean> {
    const document = this.documents.get(id);
    if (!document) return false;
    
    // Delete image file
    if (document.imagePath) {
      const imagePath = path.join(process.cwd(), document.imagePath.replace(/^\/uploads/, 'uploads'));
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
      }
    }
    
    // Update category count
    await this.updateCategoryCount(document.categoryId, -1);
    
    // Delete document
    return this.documents.delete(id);
  }
}

export const storage = new MemStorage();
